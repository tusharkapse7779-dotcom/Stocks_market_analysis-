import plotly.graph_objects as go
import streamlit as st

def price_chart(df):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df.index, y=df['Close'], mode='lines', name='Close'))
    if 'SMA' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['SMA'], mode='lines', name='SMA(14)', line=dict(dash='dot')))
    fig.update_layout(template='plotly_dark', height=450, margin=dict(l=20,r=20,t=40,b=20))
    st.plotly_chart(fig, use_container_width=True)
