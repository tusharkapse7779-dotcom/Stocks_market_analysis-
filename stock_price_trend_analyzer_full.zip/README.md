# Stock Price Trend Analyzer

This repository contains a Streamlit dashboard and supporting code to analyze stock price trends,
compute technical indicators, and (optionally) run an LSTM model for short-term price prediction.

## Contents
- `app.py` — Single-file Streamlit app (dashboard + LSTM prediction UI)
- `src/` — helper modules (data fetch, preprocessing, charts, models)
- `src/training/train_lstm.py` — script to train and save an LSTM model locally
- `models_saved/` — placeholder for trained models (add your `lstm_model.h5` here)
- `requirements.txt` — Python dependencies

## Quickstart (local)

1. Create and activate venv:
```bash
python -m venv venv
source venv/bin/activate  # macOS / Linux
venv\Scripts\activate   # Windows
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

> Note: `tensorflow` is optional and only required if you plan to train or load the LSTM model.

3. Run the app:
```bash
streamlit run app.py
```

## Training LSTM locally
Use `python src/training/train_lstm.py --help` for usage. The script will save `models_saved/lstm_trained.h5`
and `models_saved/scaler_trained.pkl` which the app can then use for live predictions.

## License
MIT
