import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sklearn.preprocessing import MinMaxScaler
import joblib
import os

st.set_page_config(page_title='Stock Price Trend Analyzer', layout='wide')
st.title('📈 Stock Price Trend Analyzer')

# ---------------- Helpers ----------------
def fetch_last_n_days(ticker: str, n_days: int = 100):
    df = yf.download(ticker, period=f"{n_days}d", interval='1d', progress=False)
    if df.empty:
        raise RuntimeError("No data found. Check ticker symbol.")
    df.index = pd.to_datetime(df.index)
    return df

def add_sma(df, window=14):
    df = df.copy()
    df['SMA'] = df['Close'].rolling(window).mean()
    return df

def add_rsi(df, period=14):
    df = df.copy()
    delta = df['Close'].diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = -delta.clip(upper=0).rolling(period).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100/(1+rs))
    return df

def plot_price(df):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df.index, y=df['Close'], mode='lines', name='Close'))
    if 'SMA' in df.columns:
        fig.add_trace(go.Scatter(x=df.index, y=df['SMA'], mode='lines', name='SMA(14)', line=dict(dash='dot')))
    fig.update_layout(template='plotly_dark', height=450)
    st.plotly_chart(fig, use_container_width=True)

# -------------- UI ----------------
ticker = st.text_input('Enter NSE symbol (e.g., RELIANCE.NS)', 'RELIANCE.NS')
days = st.slider('Days to fetch', 60, 1500, 300)

if st.button('Analyze'):
    try:
        df = fetch_last_n_days(ticker, days)
        df = add_sma(df, 14)
        df = add_rsi(df, 14)

        col1, col2 = st.columns([3,1])
        with col1:
            st.subheader(f'{ticker} — Last {days} days')
            plot_price(df)

        with col2:
            st.metric('Current Price', round(df['Close'].iloc[-1],2))
            st.metric('SMA(14)', round(df['SMA'].iloc[-1],2))
            st.metric('RSI(14)', round(df['RSI'].iloc[-1],2))

        st.subheader('Recent Data')
        st.dataframe(df.tail(20))

        # LSTM prediction UI
        st.markdown('---')
        st.subheader('🔮 LSTM Future Price Prediction (7 days)')
        model_path = 'models_saved/lstm_trained.h5'
        scaler_path = 'models_saved/scaler_trained.pkl'
        if os.path.exists(model_path) and os.path.exists(scaler_path):
            try:
                from tensorflow.keras.models import load_model
                model = load_model(model_path)
                scaler = joblib.load(scaler_path)

                if st.button('Predict Next 7 Days'):
                    # prepare scaled last seq
                    seq_len = 60
                    if len(df) < seq_len:
                        st.error(f'Need at least {seq_len} days of data for prediction.')
                    else:
                        scaled = scaler.transform(df[['Close']].values)
                        last_seq = scaled[-seq_len:].reshape(1, seq_len, 1)
                        preds_scaled = []
                        tmp = last_seq.copy()
                        for _ in range(7):
                            p = model.predict(tmp)[0][0]
                            preds_scaled.append(p)
                            tmp = np.append(tmp[:,1:,:], [[[p]]], axis=1)
                        preds = scaler.inverse_transform(np.array(preds_scaled).reshape(-1,1)).flatten()

                        dates = pd.date_range(start=df.index[-1] + pd.Timedelta(days=1), periods=7, freq='B')
                        out_df = pd.DataFrame({'Date': dates, 'Predicted_Close': preds})
                        out_df.set_index('Date', inplace=True)
                        st.table(out_df)

                        fig = go.Figure()
                        fig.add_trace(go.Scatter(x=out_df.index, y=out_df['Predicted_Close'], mode='lines+markers', name='Prediction'))
                        fig.update_layout(template='plotly_dark', height=350)
                        st.plotly_chart(fig, use_container_width=True)
            except Exception as e:
                st.error(f'Failed to load model for prediction: {e}')
        else:
            st.info('No trained LSTM model found in `models_saved/`. To enable live LSTM predictions, train locally using `src/training/train_lstm.py` which will generate `models_saved/lstm_trained.h5` and `models_saved/scaler_trained.pkl`.')
            st.write('You can still use the dashboard without the model.')

    except Exception as e:
        st.error(f'Error: {e}')
