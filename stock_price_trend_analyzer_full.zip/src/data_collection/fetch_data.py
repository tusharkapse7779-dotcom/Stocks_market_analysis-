import yfinance as yf
import pandas as pd

def fetch_last_n_days(ticker: str, n_days: int = 100) -> pd.DataFrame:
    """Fetch last n_days of daily OHLCV data using yfinance."""
    period = f"{n_days}d"
    df = yf.download(ticker, period=period, interval='1d', progress=False)
    if df.empty:
        raise RuntimeError('No data fetched. Check ticker symbol or network.')
    df.index = pd.to_datetime(df.index)
    return df
