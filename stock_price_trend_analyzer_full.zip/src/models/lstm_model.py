# Lightweight LSTM model example (used if training locally)
try:
    from tensorflow.keras import Sequential
    from tensorflow.keras.layers import LSTM, Dense
except Exception:
    # TensorFlow may not be installed in all environments.
    Sequential = None

def create_lstm(input_shape=(60,1)):
    if Sequential is None:
        raise RuntimeError('TensorFlow is not installed.')
    model = Sequential([
        LSTM(64, input_shape=input_shape, return_sequences=False),
        Dense(32, activation='relu'),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mse')
    return model
