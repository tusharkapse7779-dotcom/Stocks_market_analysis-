"""Train LSTM on historical stock data fetched via yfinance and save model weights.
Run locally: python src/training/train_lstm.py --ticker RELIANCE.NS --days 1000 --epochs 30
"""
import argparse
import os
import joblib
import numpy as np
import pandas as pd
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
try:
    from tensorflow.keras import Sequential
    from tensorflow.keras.layers import LSTM, Dense
    from tensorflow.keras.callbacks import EarlyStopping
except Exception:
    raise RuntimeError('TensorFlow is required to run this training script. Install tensorflow and try again.')

def fetch(ticker, days=1000):
    period = f"{days}d"
    df = yf.download(ticker, period=period, interval='1d', progress=False)
    df = df[['Close']].dropna()
    return df

def create_sequences(values, seq_len=60):
    X, y = [], []
    for i in range(len(values) - seq_len):
        X.append(values[i:i+seq_len])
        y.append(values[i+seq_len])
    X = np.array(X)
    y = np.array(y)
    return X.reshape((X.shape[0], X.shape[1], 1)), y

def build_model(input_shape):
    model = Sequential([
        LSTM(64, input_shape=input_shape),
        Dense(32, activation='relu'),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mse')
    return model

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--ticker', type=str, default='RELIANCE.NS')
    parser.add_argument('--days', type=int, default=1000)
    parser.add_argument('--seq', type=int, default=60)
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--out', type=str, default='models_saved')
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    print(f"Fetching {args.ticker} for last {args.days} days...")
    df = fetch(args.ticker, days=args.days)
    print('Data points fetched:', len(df))

    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(df[['Close']].values)

    X, y = create_sequences(scaled, seq_len=args.seq)
    model = build_model((args.seq, 1))

    es = EarlyStopping(monitor='loss', patience=5, restore_best_weights=True)
    model.fit(X, y, epochs=args.epochs, batch_size=32, callbacks=[es])

    model_path = os.path.join(args.out, 'lstm_trained.h5')
    scaler_path = os.path.join(args.out, 'scaler_trained.pkl')
    model.save(model_path)
    joblib.dump(scaler, scaler_path)

    print('Saved model to', model_path)
    print('Saved scaler to', scaler_path)
